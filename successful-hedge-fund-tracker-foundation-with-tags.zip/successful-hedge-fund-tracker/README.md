# Successful Hedge Fund Investment Tracker

Foundation for a GitHub-hosted tracker of 8 hedge-fund entities, SEC 13F/13D filings, historical holdings, and cross-fund analysis.

Tracked entities: Citadel, D.E. Shaw, Millennium, TCI, Pershing Square, Elliott, AQR, Lone Pine.

## Setup
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export SEC_USER_AGENT="Your Name your-email@example.com"
python -m src.database.seed
```

The SEC User-Agent should identify the application and a contact email.
